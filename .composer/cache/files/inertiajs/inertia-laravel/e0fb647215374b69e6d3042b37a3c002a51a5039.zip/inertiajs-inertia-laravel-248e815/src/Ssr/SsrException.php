<?php

namespace Inertia\Ssr;

use Exception;

class SsrException extends Exception {}
