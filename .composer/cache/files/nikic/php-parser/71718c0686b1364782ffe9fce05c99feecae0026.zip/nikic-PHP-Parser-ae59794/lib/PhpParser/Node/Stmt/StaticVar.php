<?php declare(strict_types=1);

namespace PhpParser\Node\Stmt;

require __DIR__ . '/../StaticVar.php';

if (false) {
    // For classmap-authoritative support.
    class StaticVar extends \PhpParser\Node\StaticVar {
    }
}
